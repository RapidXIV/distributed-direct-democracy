# Distributed Direct Democracy (Phase One)

A single-file demo that runs entirely in the browser.

**Deploy on GitHub Pages:** Upload these files to a public repo, then enable Pages (Settings → Pages → Source: Deploy from a branch, Branch: `main`, Folder: `/ (root)`). Your site URL will be:

```
https://<your-username>.github.io/<your-repo-name>/
```

## What it does
- Asks: **“What should we do?”**
- Auto-merges similar ideas (local TF-IDF + cosine)
- Voting, clustering, transparency log
- Import/Export JSON
- Offline, no servers, no trackers

## How to use
Open `index.html` in any modern browser.

## License
MIT
